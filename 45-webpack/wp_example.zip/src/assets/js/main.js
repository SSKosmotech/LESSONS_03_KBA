import 'bootstrap';

console.log("Hello!");
